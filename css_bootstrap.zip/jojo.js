// js code in first page




// work with img, coins
function enlargeImage(img, listId) {
  var list = document.getElementById(listId);
  var allImages = list.querySelectorAll('img');
  allImages.forEach(function (image) {
      image.classList.remove('enlarged');
  });

  img.classList.add('enlarged');
}
function enlargeImage1(img, listId) {
  var list = document.getElementById(listId);
  var allImages = list.querySelectorAll('img');
  allImages.forEach(function (image) {
      image.classList.remove('enlarged');
  });

  img.classList.add('enlarged');
}




// Changing language
function toggleDropdown() {
  var dropdown = document.getElementById("myDropdown");
  dropdown.classList.toggle("show");
}

window.onclick = function (event) {
  if (!event.target.matches('.dropbtn')) {
      var dropdowns = document.getElementsByClassName("dropdown-content");
      for (var i = 0; i < dropdowns.length; i++) {
          var openDropdown = dropdowns[i];
          if (openDropdown.classList.contains('show')) {
              openDropdown.classList.remove('show');
          }
      }
  }
};


// coin showing, for give
function showAltText(image) {
  // Get the alt attribute of the clicked image
  const altText = image.alt;

  // Display the alt text
  const altTextDisplay = document.getElementById("altTextDisplay");
  altTextDisplay.textContent = altText;
}

//func for recieve
function showAltText1(image) {
  // Get the alt attribute of the clicked image
  const altText = image.alt;

  // Display the alt text
  const altTextDisplay = document.getElementById("altTextDisplay1");
  altTextDisplay.textContent = altText;
}



//Show coin currency price, real time, using API of Coingekko.

async function fetchCryptoPrice(cryptoId) {
  try {
      // Display "Loading..." message
      document.getElementById('cryptoPrice').textContent = 'Loading...';

      // Make an API request to CoinGecko for cryptocurrency price
      const response = await fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${cryptoId}&vs_currencies=usd`);
      const data = await response.json();
      
      // Extract cryptocurrency price from the response
      const cryptoPrice = data[cryptoId].usd;

      // Display the price on the webpage
      document.getElementById('cryptoPrice').textContent = `${cryptoPrice}` + "$";
  } catch (error) {
      console.error('Error fetching cryptocurrency price:', error);
      document.getElementById('cryptoPrice').textContent = 'Error fetching price';
  }
}

// for receive
async function fetchCryptoPrice1(cryptoId) {
  try {
      // Display "Loading..." message
      document.getElementById('cryptoPrice1').textContent = 'Loading...';

      // Make an API request to CoinGecko for cryptocurrency price
      const response = await fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${cryptoId}&vs_currencies=usd`);
      const data = await response.json();
      
      // Extract cryptocurrency price from the response
      const cryptoPrice = data[cryptoId].usd;

      // Display the price on the webpage
      document.getElementById('cryptoPrice1').textContent = `${cryptoPrice}` + "$";
  } catch (error) {
      console.error('Error fetching cryptocurrency price:', error);
      document.getElementById('cryptoPrice1').textContent = 'Error fetching price';
  }
}



// good job

// Get the scroll-to-top button element
const scrollToTopBtn = document.getElementById("scrollToTopBtn");

// Show the button when user scrolls down 50px from the top of the document
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
        scrollToTopBtn.style.display = "block";
    } else {
        scrollToTopBtn.style.display = "none";
    }
}

// When the user clicks on the button, scroll to the top of the document
scrollToTopBtn.addEventListener("click", () => {
    document.body.scrollTop = 0; // For Safari
    document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
});